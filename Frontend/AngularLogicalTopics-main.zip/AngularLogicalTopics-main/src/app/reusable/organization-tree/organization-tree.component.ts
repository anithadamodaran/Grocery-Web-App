import { Component } from '@angular/core';

@Component({
  selector: 'app-organization-tree',
  templateUrl: './organization-tree.component.html',
  styleUrls: ['./organization-tree.component.css']
})
export class OrganizationTreeComponent {

}
