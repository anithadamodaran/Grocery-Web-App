
import { Component } from '@angular/core';

@Component({
  selector: 'app-content-projection',
  templateUrl: './content-projection.component.html',
  styleUrls: ['./content-projection.component.css']
})
export class ContentProjectionComponent {

  obj: any = {
    fname: '',
    lName: '',
    userName: '',
    city: '',
  }
 
  
}
