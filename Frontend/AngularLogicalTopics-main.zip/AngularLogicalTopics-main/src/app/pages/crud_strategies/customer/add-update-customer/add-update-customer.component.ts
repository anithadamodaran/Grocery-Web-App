import { Component } from '@angular/core';

@Component({
  selector: 'app-add-update-customer',
  templateUrl: './add-update-customer.component.html',
  styleUrls: ['./add-update-customer.component.css']
})
export class AddUpdateCustomerComponent {

  studentObj: any = {
    
  }
}
