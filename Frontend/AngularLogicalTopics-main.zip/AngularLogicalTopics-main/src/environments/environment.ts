export const environment = {
  production: false,
  apiEndPoint: "https://akbarapi.funplanetresort.in/api/MyRequest/"
};
